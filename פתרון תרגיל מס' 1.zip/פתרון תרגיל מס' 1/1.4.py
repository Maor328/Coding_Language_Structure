# Dictionary mapping each Hebrew letter to its Gematria value
gematria_dict = {
    'א': 1, 'ב': 2, 'ג': 3, 'ד': 4, 'ה': 5, 'ו': 6, 'ז': 7, 'ח': 8, 'ט': 9, 'י': 10,
    'כ': 20, 'ך': 20, 'ל': 30, 'מ': 40, 'ם': 40, 'נ': 50, 'ן': 50, 'ס': 60, 'ע': 70, 
    'פ': 80, 'ף': 80, 'צ': 90, 'ץ': 90, 'ק': 100, 'ר': 200, 'ש': 300, 'ת': 400
}

def calc_gematria(word):
    # Sum the values of the characters. 
    # get(char, 0) returns 0 if the character is not in the dictionary.
    return sum(gematria_dict.get(char, 0) for char in word)